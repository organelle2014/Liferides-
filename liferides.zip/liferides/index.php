﻿<?php
    require_once ('class/userPost/userpost.php');

    /*this code for user post*/
    $obj_userPost = new Userpost();
    $result = $obj_userPost->all_userPost_info();

    require_once('class/userPost/feedback.php');
    /*this code for client Feedback*/
    $obj_feedback = new Feedback();
    $feedback_result = $obj_feedback->all_clientFeedback_info();

    /*this code for user post in footer*/
    $user_post_result = $obj_userPost->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_userPost->all_userPost_picture_for_footer();

    /*this code for contact us Address in main content*/
    $contact_address = $obj_userPost->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in main content*/
    $social_address = $obj_userPost->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);

    include 'header.php';
?>

<!-- banner start-->
<div class="banner">
    <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
        <!-- Wrapper for slides -->
        <div class="carousel-inner" role="listbox">
            <div class="item active item-1">
                <div class="container">
                    <div class="banner-slider-inner-1">
                        <h1>WE ARE HERE FOR YOU</h1>
                        <h2>Fill Up Your Dream</h2>
                        <h4>Take a, High Gorgeous, &amp; Mindblowing<br>Outstanding Technologiful Car</h4>
                    </div>
                </div>
            </div>
            <div class="item item-2">
                <div class="container">
                        <div class="banner-slider-inner-1">
                        <h1>Explore <span>Your Dream</span></h1>
                        <h4>Your Comfortness is Our Satisfaction</h4>
                        <div class="Website-text">LifeRides Eldoret.</div>
                    </div>
                </div>
            </div>
            <div class="item item-3">
                <div class="container">
                     <div class="banner-slider-inner-1">
                        <h1><span>Our Car</span><br>Gives you Happiness</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- Controls -->
        <a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
          <span class="slider-mover-left" aria-hidden="true">
             <img src="mainSite/img/png/left-chevron.png" alt="left-chevron">
          </span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
            <span class="slider-mover-right" aria-hidden="true">
                <img src="mainSite/img/png/right-chevron.png" alt="right-chevron">
            </span>
            <span class="sr-only">Next</span>
        </a>
    </div>
</div>
<!-- banner end-->

<!-- Recent car start-->
<div class="recent-car content-area">
    <div class="container">
        <div class="recent-car-content">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="section-heading">
                        <i class="fa fa-car"></i>
                        <h2>Recent Selling cars</h2>
                        <div class="border"></div>
                        <h4>Choose Your Dream car</h4>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php foreach ($result as $all_result){ ?>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <div class="thumbnail car-box">
                            <!--<img src="mainSite/<?php /*$len = strlen($all_result['car_image']); $image = substr($all_result['car_image'],3,$len); echo $image;*/?>" alt="car-image" height="700" width="700">-->
                            <img src="mainSite/assets/image/<?php echo $all_result['car_image']?>" alt="car-image" height="700" width="700">
                            <div class="caption car-content">
                                <div class="header b-items-cars-one-info-header s-lineDownLeft">
                                    <h3>
                                        <a href="mainSite/car_details.php?id=<?php echo $all_result['user_post_id'] ?>"><?php echo $all_result['car_name']; ?></a>
                                        <span> Ksh: <?php echo $all_result['car_price']?></span>
                                    </h3>
                                </div>

                                <p class="text-justify"><?php echo substr($all_result['car_details'],0,150)." ...";?></p>
                                <!--<div class="car-tags">
                                    <ul>
                                        <li>2017</li>
                                        <li>Bensin</li>
                                        <li>Sport</li>
                                        <li>12.888m</li>
                                    </ul>
                                </div>-->
                                <div class="ster-fa">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                </div>
                                <a href="mainSite/car_details.php?id=<?php echo $all_result['user_post_id'] ?>" class="btn details-button">Details</a>
                            </div>
                        </div>
                    </div>
                <?php } ?>

            </div>
        </div>
    </div>
</div>
<!-- Recent car end-->

<!-- Testimonials start-->
<div class="testimonials">
    <div class="col-lg-12">
        <div id="carouse2-example-generic" class="carousel slide" data-ride="carousel">
            <!-- Indicators -->
            <ol class="carousel-indicators">
                <?php $i =0; foreach ($feedback_result as $all_feedback_result){  if($i==0){ ?>
                <li data-target="#carouse2-example-generic" data-slide-to="<?php echo $i;?>" class="active"></li>
                <?php }else{ ?>
                <li data-target="#carouse2-example-generic" data-slide-to="<?php echo $i;?>"></li>
                <?php } $i++; }?>
            </ol>

            <!-- Wrapper for slides -->
            <div class="carousel-inner" role="listbox">
                <?php $i =0; foreach ($feedback_result as $all_feedback_result){  ?>
                    <?php if($i==0){?>
                <div class="item active">
                    <?php }else{?>
                <div class="item">
                    <?php }?>
                    <div class="container">
                        <div class="col-md-8 col-md-offset-2 testimonials-inner">
                                <h3 class="text-success">What Our Client Say</h3>
                                <div class="line-dec"></div>
                                    <p>
                                        <em>"</em>
                                        <?php echo $all_feedback_result['feeadback_message']?>
                                        <em>"</em>
                                    </p>
                                    <div class="author-rate">
                                        <img src="mainSite/<?php echo $all_feedback_result['client_image']?>" alt="client_feedback_image">
                                        <h4><?php echo $all_feedback_result['client_name']?></h4>
                                        <div class="line-dec2"></div>
                                        <span><?php echo $all_feedback_result['client_type']?></span>
                                    </div>
                        </div>
                    </div>
                </div>
                <?php $i++; } ?>
            </div>
            <!-- Controls -->
            <a class="left carousel-control" href="#carouse2-example-generic" role="button" data-slide="prev">
              <span class="slider-mover-left" aria-hidden="true">
                 <img src="mainSite/img/png/left-chevron.png" alt="left-chevron">
              </span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="right carousel-control" href="#carouse2-example-generic" role="button" data-slide="next">
                <span class="slider-mover-right" aria-hidden="true">
                    <img src="mainSite/img/png/right-chevron.png" alt="right-chevron">
                </span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <div class="clearfix"></div>
</div>
<!-- Testimonials end-->

<!-- Footer begins here-->
<?php include'footer.php';?>