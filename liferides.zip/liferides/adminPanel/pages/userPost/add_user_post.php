<?php
    session_start();
    $message = '';


    if($_SESSION['admin_id'] == null){
        header('Location: ../../../admin/index.php');
    }

    if(isset($_GET['logout'])){
        require_once('../../../class/adminLogin/login.php');
        $obj_login = new Login();
        $obj_login->admin_logout2();
    }

    /*add user post code*/
    require_once ('../../../class/userPost/userpost.php');
    /*update User Post info*/
    if (isset($_POST['btn'])){
        $fuel_type=$_POST['fuel_type'];
        $commaSeparatedFuelType=implode(",",$fuel_type);
        $_POST['fuel_type']=$commaSeparatedFuelType;

        $others=$_POST['others'];
        $commaSeparatedOthers=implode(",",$others);
        $_POST['others']=$commaSeparatedOthers;

        $obj_user_post = new Userpost();
        $obj_user_post->save_userPost_info($_POST);
    }
?>
<?php include'dashboard.php';?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Admin | Edit User Post</title>
    <!-- Tell the browser to be responsive to screen width -->
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
    <!-- Bootstrap 3.3.6 -->
    <link rel="stylesheet" href="../../bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
    <!-- Ionicons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
    <!-- Theme style -->
    <link rel="stylesheet" href="../../dist/css/AdminLTE.min.css">
    <!-- AdminLTE Skins. Choose a skin from the css/skins
         folder instead of downloading all of them to reduce the load. -->
    <link rel="stylesheet" href="../../dist/css/skins/_all-skins.min.css">
    <!-- iCheck -->
    <link rel="stylesheet" href="../../plugins/iCheck/flat/blue.css">
    <!-- Morris chart -->
    <link rel="stylesheet" href="../../plugins/morris/morris.css">
    <!-- jvectormap -->
    <link rel="stylesheet" href="../../plugins/jvectormap/jquery-jvectormap-1.2.2.css">
    <!-- Date Picker -->
    <link rel="stylesheet" href="../../plugins/datepicker/datepicker3.css">
    <!-- Daterange picker -->
    <link rel="stylesheet" href="../../plugins/daterangepicker/daterangepicker.css">
    <!-- bootstrap wysihtml5 - text editor -->
    <link rel="stylesheet" href="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">



    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <!-- Main content -->

        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <!--Success Message -->
                    <h3 class="text-center text-success"><?php echo $message; ?></h3>
                    <br>
                    <!--end -->
                    <div class="well" style="margin-top: 20px">
                        <h3 class="text-center text-success">Add New Car Information Here</h3><br>

                        <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <label for="car_name" class="col-sm-2 control-label">Car Name</label>
                                <div class="col-sm-8">
                                    <input type="text" name="car_name" class="form-control" required>
                                    <input type="hidden" name="user_post_id" class="form-control">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="car_price" class="col-sm-2 control-label">Car Price</label>
                                <div class="col-sm-8">
                                    <input type="text" name="car_price" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="car_details" class="col-sm-2 control-label">Car Details</label>
                                <div class="col-sm-8">
                                    <textarea name="car_details" class="form-control" rows="4" /></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="car_model" class="col-sm-2 control-label">Car Model Year</label>
                                <div class="col-sm-8">
                                    <input type="text" name="car_model" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="car_registration" class="col-sm-2 control-label">Car Registration Year</label>
                                <div class="col-sm-8">
                                    <input type="text" name="car_registration" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="cng_status" class="col-sm-2 control-label">CNG Status</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="cng_status" value="Yes"> Yes
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="cng_status" value="No"> No
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="cng_com" class="col-sm-2 control-label">CNG Company</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="cng_com" value="Navana"> Navana
                                </div>
                                <div class="col-sm-2">
                                    <input type="radio" name="cng_com" value="Southern"> Southern
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="cng_com" value="Others"> Others
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="fuel_type[]" class="col-sm-2 control-label">Fuel Type</label>
                                <div class="col-sm-1">
                                    <input type="checkbox" name="fuel_type[]" value="Gas"> Gas
                                </div>
                                <div class="col-sm-1">
                                    <input type="checkbox" name="fuel_type[]" value="Diesel"> Diesel
                                </div>
                                <div class="col-sm-1">
                                    <input type="checkbox" name="fuel_type[]" value="Octen"> Octen
                                </div>
                                <div class="col-sm-1">
                                    <input type="checkbox" name="fuel_type[]" value="Others"> Others
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="car_cc" class="col-sm-2 control-label">Car CC</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="1000"> 1000
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="1300"> 1300
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="1500"> 1500
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="1800"> 1800
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="2000"> 2000
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="2500"> 2500
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="car_cc" value="Others"> Others
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="gear" class="col-sm-2 control-label">Gear Type</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="gear" value="Auto"> Auto
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="gear" value="Manual"> Manual
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="all_option" class="col-sm-2 control-label">All Option</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="all_option" value="Auto"> Auto
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="all_option" value="Manual"> Manual
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="music" class="col-sm-2 control-label">Music Media</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="music" value="CD"> CD
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="music" value="DVD"> DVD
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="serial_number" class="col-sm-2 control-label">Car Serial Number</label>
                                <div class="col-sm-8">
                                    <input type="text" name="serial_number" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="engine" class="col-sm-2 control-label">Engine Type</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="engine" value="EFI"> EFI
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="engine" value="VVTI"> VVTI
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="engine" value="Others"> Others
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="mileage" class="col-sm-2 control-label">Car Mileage</label>
                                <div class="col-sm-8">
                                    <input type="text" name="mileage" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="doors" class="col-sm-2 control-label">Doors Number</label>
                                <div class="col-sm-8">
                                    <input type="text" name="doors" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="condtion" class="col-sm-2 control-label">Car Conditon</label>
                                <div class="col-sm-2">
                                    <input type="radio" name="condtion" value="Brand New"> Brand New
                                </div>
                                <div class="col-sm-2">
                                    <input type="radio" name="condtion" value="Second Hand"> Second Hand
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="condtion" value="Others"> Others
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="passenger" class="col-sm-2 control-label">Passenger Capacity</label>
                                <div class="col-sm-8">
                                    <input type="text" name="passenger" class="form-control" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="color" class="col-sm-2 control-label">Car Color</label>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="White"> White
                                </div>
                                <div class="col-sm-2">
                                    <input type="radio" name="color" value="Parl White"> Parl White
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Black"> Black
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Red"> Red
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Banson"> Banson
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Blue"> Blue
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Grey"> Grey
                                </div>
                                <div class="col-sm-1">
                                    <input type="radio" name="color" value="Others"> Others
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="others[]" class="col-sm-2 control-label">Car Others Have</label>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Air Conditioning" >  Air Conditioning
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Alarm System" > Alarm System
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Audio Interface" > Audio Interface
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Automatic Headlights" > Automatic Headlights
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Auto Start/Stop" > Auto Start/Stop
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Bluetooth"> Bluetooth
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="CD/DVD Autochanger" > CD/DVD Autochanger
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Floor Mats" > Floor Mats
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Manual Transmission" > Manual Transmission
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Reversing Camera" > Reversing Camera
                                </div>
                                <label for="others[]" class="col-sm-2 control-label"></label>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Seat Heating" > Seat Heating
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Seat Ventilationn" > Seat Ventilation
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Steering Wheel Heating" > Steering Wheel Heating
                                </div>
                                <div class="col-sm-2">
                                    <input type="checkbox" name="others[]" value="Voice Control System" > Voice Control System
                                </div>
                            </div>


                            <div class="form-group">
                                <label for="car_image" class="col-sm-2 control-label">Car Image</label>
                                <div class="col-sm-8">
                                    <input type="file" name="car_image" accept="image/*">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="publication_status" class="col-sm-2 control-label">Publication Status</label>
                                <div class="col-sm-8">
                                    <select name="publication_status" class="form-control">
                                        <option>---Select Publication Status---</option>
                                        <option value="1">Published</option>
                                        <option value="0">Unpublished</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="btn" class="col-sm-2 control-label"></label>
                                <div class="col-sm-8">
                                    <button type="submit" name="btn" class="btn btn-success btn-block">Save Car Info</button>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

                <!-- /.control-sidebar-menu -->

            </div>
            
                    <!-- /.form-group -->

                    
                    <!-- /.form-group -->

                    
                    <!-- /.form-group -->

                    
                    <!-- /.form-group -->
        
            </div>
            <!-- /.tab-pane -->
        </div>
    </aside>
    <!-- /.control-sidebar -->
    <!-- Add the sidebar's background. This div must be placed
         immediately after the control sidebar -->

</div>
<!-- ./wrapper -->

<!-- jQuery 2.2.3 -->
<script src="../../plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="../../https://code.jquery.com/ui/1.11.4/jquery-ui.min.js"></script>
<!-- Resolve conflict in jQuery UI tooltip with Bootstrap tooltip -->
<script>
    $.widget.bridge('uibutton', $.ui.button);
</script>
<!-- Bootstrap 3.3.6 -->
<script src="../../bootstrap/js/bootstrap.min.js"></script>
<!-- Morris.js charts -->
<script src="../../https://cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="../../plugins/morris/morris.min.js"></script>
<!-- Sparkline -->
<script src="../../plugins/sparkline/jquery.sparkline.min.js"></script>
<!-- jvectormap -->
<script src="../../plugins/jvectormap/jquery-jvectormap-1.2.2.min.js"></script>
<script src="../../plugins/jvectormap/jquery-jvectormap-world-mill-en.js"></script>
<!-- jQuery Knob Chart -->
<script src="../../plugins/knob/jquery.knob.js"></script>
<!-- daterangepicker -->
<script src="../../https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="../../plugins/daterangepicker/daterangepicker.js"></script>
<!-- datepicker -->
<script src="../../plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- Bootstrap WYSIHTML5 -->
<script src="../../plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.all.min.js"></script>
<!-- Slimscroll -->
<script src="../../plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- FastClick -->
<script src="../../plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/app.min.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="../../dist/js/pages/dashboard.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
</body>
</html>
