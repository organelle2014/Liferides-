<?php
    require_once ('../class/userPost/userpost.php');

    /*this code for user post*/
    $obj_userPost = new Userpost();
    $result = $obj_userPost->all_userPost_info();

    /*this code for user post in footer*/
    $user_post_result = $obj_userPost->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_userPost->all_userPost_picture_for_footer();

    /*this code for contact us Address in main content*/
    $contact_address = $obj_userPost->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in main content*/
    $social_address = $obj_userPost->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);

?>

<?php  include'headermain.php';?>

<!-- Car list start-->
<div class="car-list content-area">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
               <div class="option-bar">
                   <div class="row">
                       <div class="col-lg-6 col-md-6 col-sm-6">
                           <div class="section-heading">
                               <i class="fa fa-car"></i>
                               <h2>Recent Selling cars</h2>
                               <div class="border"></div>
                               <h4>Choose Your Dream car</h4>
                           </div>
                       </div>
                       <div class="col-lg-6 col-md-6 col-sm-6 text-right">
                           <div class="sorting-options">
                               <a href="car_buy.php" class="change-view-btn active-view-btn"><i class="fa fa-th-list"></i></a>
                               <a href="car_grid.php" class="change-view-btn"><i class="fa fa-th-large"></i></a>
                           </div>
                       </div>
                   </div>
               </div>
                
                <!-- List car start-->
                <div class="list-car-box">
                    <?php foreach ($result as $all_result){ ?>
                        <div class="row">
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 list-car-pic clearfix">
                                <img src="assets/image/<?php echo $all_result['car_image'];?>" alt="vencer_sarthe_supercar" class="img-responsive">
                            </div>
                            <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 car-content clearfix">
                                <div class="header b-items-cars-one-info-header  s-lineDownLeft">
                                    <h3>
                                        <a href="car_details.php"><?php echo $all_result['car_name'];?></a>
                                        <span>Ksh: <?php echo $all_result['car_price']?></span>
                                    </h3>
                                </div>
                                <div class="line-border"></div>

                                <p><?php echo substr($all_result['car_details'],0,150)." ...";?></p>

                                <div class="item">
                                    <div class="col-md-5 col-sm-5 col-xs-12 col-pad">
                                        <p>
                                            <span>Car Model:</span> <?php echo $all_result['car_model']?>
                                        </p>
                                        <p>
                                            <span>Car CC:</span><?php echo $all_result['car_cc']?>
                                        </p>
                                        <p>
                                            <span>Car Mileage:</span><?php echo $all_result['mileage']?>
                                        </p>

                                    </div>
                                    <div class="col-md-5 col-sm-5 col-xs-12 col-pad">
                                        <p>
                                            <span>Car Registration:</span><?php echo $all_result['car_registration']?>
                                        </p>
                                        <p>
                                            <span>Car Color:</span><?php echo $all_result['color']?>
                                        </p>
                                        <p>
                                            <span>Passenger Capacity:</span><?php echo $all_result['passenger']?>
                                        </p>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12 col-pad">
                                        <br>
                                        



                                        <!-- Trigger the modal with a button -->
                                    <button type="button" class="btn btn-danger btn-sm" data-toggle="modal" data-target="#myModal">Rent Car</button>

                                    <!-- Modal -->
                                    <div id="myModal" class="modal fade" role="dialog">
                                      <div class="modal-dialog">

                                        <!-- Modal content-->
                                        <div class="modal-content">
                                          <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                                            <h4 class="modal-title">Fill in the form</h4>
                                          </div>
                                          <div class="modal-body">
                                                <form class="login">
                    
                                                    <div class="form-group">
                                                        <label for="username">Block Names:</label>
                                                        <input type="email" class="input-text" name="email" placeholder="Full Name..." required>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="username">Phone</label>
                                                        <input type="email" class="input-text" name="email" placeholder="=254 7... ..." required>
                                                    </div>
                                                 </form>
                                            


                                            <p>We will get back to you Soon.</p>
                                          </div>
                                          <div class="modal-footer">
                                            <button type="button" class="btn btn-default" data-dismiss="modal"><a href="car_details.php?id=<?php echo $all_result['user_post_id'] ?>" class="btn details-button">Rent</a></button>
                                          </div>
                                        </div>

                                      </div>
                                    </div>





                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php echo "<br><br>"; } ?>
                </div>

                <!-- List car End-->


                <!-- Page navigation start-->
                <nav aria-label="Page navigation">
                    <ul class="pagination">
                        <li>
                            <a href="#" aria-label="Previous">
                                <span aria-hidden="true">&laquo;</span>
                            </a>
                        </li>
                        <li class="active"><a href="#">1 <span class="sr-only">(current)</span></a></li>
                        <li><a href="#">2</a></li>
                        <li><a href="#">3</a></li>
                        <li><a href="#">4</a></li>
                        <li><a href="#">5</a></li>
                        <li>
                            <a href="#" aria-label="Next">
                                <span aria-hidden="true">&raquo;</span>
                            </a>
                        </li>
                    </ul>
                </nav> 
                <!-- Page navigation end-->
            </div>
            
            <div class="col-lg-4 col-md-4 col-xs-12">
                <!-- Sidebar start-->
                <aside class="sidebar">
                    <div class="section-heading">
                        <i class="fa fa-search"></i>
                        <h2>Search Car</h2>
                        <div class="border"></div>
                        <h4>Search your desire car</h4>
                    </div>

                    <div class="search-block">
                        <h2 class="title">Review Rating</h2>
                        <ul class="ratings">
                            <li>
                                <a href="#">
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <span>(100)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <span>(1525)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <span>(252)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <span>(5665)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star-o orange-color"></i>
                                    <span>(1587)</span>
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <i class="fa fa-star orange-color"></i>
                                    <span>(554)</span>
                                </a>
                            </li>
                        </ul>
                    </div>


                    <div class="search-block">
                        <h2 class="title">Brands</h2>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox8" type="checkbox">
                            <label for="checkbox8">
                                Audi
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox9" type="checkbox">
                            <label for="checkbox9">
                                BMW
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox10" type="checkbox">
                            <label for="checkbox10">
                                Mercedes benz
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox11" type="checkbox">
                            <label for="checkbox11">
                                Lamborghini
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox12" type="checkbox">
                            <label for="checkbox12">
                                Buick
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox13" type="checkbox">
                            <label for="checkbox13">
                                Bugatti
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox14" type="checkbox">
                            <label for="checkbox14">
                                Acura
                            </label>
                        </div>
                    </div>

                    <div class="search-block">
                        <h2 class="title">Popular cars</h2>
                        
                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox5" type="checkbox">
                            <label for="checkbox5">
                                Lamborghini 2016
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox7" type="checkbox">
                            <label for="checkbox7">
                                Audi
                            </label>
                        </div>
                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox4" type="checkbox">
                            <label for="checkbox4">
                                Jaguar F-Type R
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox3" type="checkbox">
                            <label for="checkbox3">
                                Porsche-Cayen-Last
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox2" type="checkbox">
                            <label for="checkbox2">
                                Mercedes Benz C Class
                            </label>
                        </div>

                        <div class="checkbox checkbox-theme checkbox-circle">
                            <input id="checkbox1" type="checkbox">
                            <label for="checkbox1">
                                Vencer Sarthe Supercar
                            </label>
                        </div>
                    </div>


                    <div class="search-block"></div>
                </aside>
                <!-- Sidebar end-->
                
                <!-- Recent news Start-->
                <div class="Recent-news">
                    <h2 class="title">Recent Selling Car</h2>
                    <?php foreach ($user_post_result as $all_user_post_result){ ?>
                        <div class="media">
                            <div class="media-left">
                                <a href="car_details.php?id=<?php echo $all_user_post_result['user_post_id'] ?>">
                                    <img class="media-object" src="assets/image/<?php echo $all_user_post_result['car_image'];?>" alt="car-image">
                                </a>
                            </div>
                            <div class="media-body">
                                <a href="car_details.php?id=<?php echo $all_user_post_result['user_post_id'] ?>"><?php echo $all_user_post_result['car_name']?></a>
                                <div class="line-dec-o"></div>
                                <span>Ksh: <?php echo $all_user_post_result['car_price']?></span>
                            </div>
                        </div>
                    <?php } ?>

                </div>
                <!-- Recent news end-->
                 
                <!-- Car box Start-->
                <div class="thumbnail car-box">
                    <a href="#" class="sale">
                        <span>sale</span>
                    </a>
                    <img src="img/grid/audi_q7_2017.jpg" alt="audi_q7_2017">
                    <div class="caption car-content">
                        <div class="header b-items-cars-one-info-header s-lineDownLeft">
                            <h3>
                                <a href="car_details.php">Audi q7 2017</a>
                                <span>$42,605</span>
                            </h3>
                        </div>
                        <p>Next level Pinterest farm-to-table selvage gentrify street art raw denim Helvetica street art pork belly.</p>
                        <div class="car-tags">
                            <ul>
                                <li>2016</li>
                                <li>Bensin</li>
                                <li>Sport</li>
                                <li>10.888m</li>
                            </ul>
                        </div>
                        <a href="car_details.php" class="btn details-button">Preview</a>
                    </div>
                </div>
                <!-- Car box end-->
            </div>
        </div>
    </div>
</div>
<!-- Car list end-->
<!-- Footer begins here-->

<?php include 'footer.php'?>