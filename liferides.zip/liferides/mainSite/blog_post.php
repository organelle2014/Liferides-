<?php
    session_start();
    require_once ('../class/blogPost/blogpost.php');

    /*this code for blog Post in main content*/
    $obj_blog_post = new Blogpost();
    $result = $obj_blog_post->all_blog_post_info();

    /*this code for user post in footer and sidebar*/
    $obj_userPost = new Blogpost();
    $user_post_result = $obj_userPost->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_userPost->all_userPost_picture_for_footer();

    /*this code for Blog Post in right Sidebar*/
    $result_for_sidebar = $obj_blog_post->all_blog_post_info_for_sidebar();

    /*this code for contact us Address in main content*/
    $contact_address = $obj_blog_post->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in main content*/
    $social_address = $obj_blog_post->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);
?>

 <!-- Blog header start-->
 <?php  include'headermain.php';?>>


<!-- Blog body start-->
<div class="blog-body">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">

                <?php foreach ($result as $all_result){ ?>
                <div class="thumbnail blog-box clearfix">
                    <img src="<?php $len = strlen($all_result['post_image']); $img = substr($all_result['post_image'],18,$len); echo $img;?>" alt="blog-image">
                    <!-- detail -->
                    <div class="caption detail">
                        <!-- Title -->
                        <h1 class="title">
                            <a href="blog_post_details.php"><?php echo $all_result['post_title']?></a>
                        </h1>
                        <!-- Post Materials-->
                        <div class="post-materials">
                            <div class="header">
                                <?php if ( isset($_SESSION['admin_name'])){?>
                                BY <a href="#"><?php echo $_SESSION['admin_name']; ?></a>
                                <?php }else{?>
                                BY <a href="#"><?php echo "Unknown" ?></a>
                                <?php } ?>
                                <i class="fa fa-clock-o"></i> <?php echo $all_result['post_Date']?><i class="fa fa-bars"></i> <a href="#"><?php echo $all_result['related_topic']?></a> <i class="fa fa-commenting-o"></i> <a href="#">3 Comment</a>
                            </div>
                            <p class="text-justify"><?php echo substr($all_result['post_details'],0,300)."...";?></p>
                            <a href="blog_post_details.php?id=<?php echo $all_result['blog_post_id']?>" class="btn btn-read-more">Read More</a>
                        </div>
                    </div>
                </div>
                <?php } ?>

            </div>

            <div class="col-lg-4 col-md-4 col-xs-12">
                <!-- Sidebar start-->
                <div class=blog-sidebar>
                    <!-- Recent news start -->
                    <div class="Recent-news">
                        <h2 class="title">Others Blog Post</h2>
                            <?php foreach ($result_for_sidebar as $all_result_for_sidebar){ ?>
                            <div class="media">
                                <div class="media-left">
                                    <a href="#">
                                        <img class="media-object" src="<?php $len = strlen($all_result_for_sidebar['post_image']); $img = substr($all_result_for_sidebar['post_image'],18,$len); echo $img;?>" alt="blog-image" alt="recent-1">
                                    </a>
                                </div>
                                <div class="media-body">
                                    <a href="blog_post_details.php"><?php echo $all_result_for_sidebar['post_title']?></a>
                                    <div class="line-dec-o"></div>
                                    <span><?php echo $all_result_for_sidebar['post_Date']?></span>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    <!-- Recent news end -->
                    <div class="clearfix"></div>
                    <!-- Blog tags start -->
                    <div class="blog-tags">
                        <h2 class="title">tags</h2>
                        <a href="#" class="tags">Apps</a>
                        <a href="#" class="tags">gallery</a>
                        <a href="#" class="tags">photography</a>
                        <a href="#" class="tags">Web</a>
                        <a href="#" class="tags">blog right sidebar</a>
                        <a href="#" class="tags">books</a>
                        <a href="#" class="tags">business</a>
                        <a href="#" class="tags">design</a>
                        <a href="#" class="tags">education</a>
                        <a href="#" class="tags">Fitness</a>
                        <a href="#" class="tags">pen</a>
                        <a href="#" class="tags">real</a>
                    </div>
                    <!-- Blog tags end -->
                    <div class="clearfix"></div>
                    
                    <!-- Recent selling car start -->
                    <div class="Recent-news popular-rooms clearfix">
                        <h2 class="title">Recent Selling Car</h2>
                            <?php foreach ($user_post_result as $all_user_post_result){ ?>
                                <div class="media">
                                    <div class="media-left">
                                        <a href="car_details.php?id=<?php echo $all_user_post_result['user_post_id'] ?>">
                                            <img class="media-object" src="assets/image/<?php echo $all_user_post_result['car_image'];?>" alt="car-image">
                                        </a>
                                    </div>
                                    <div class="media-body">
                                        <a href="car_details.php?id=<?php echo $all_user_post_result['user_post_id'] ?>"><?php echo $all_user_post_result['car_name']?></a>
                                        <div class="line-dec-o"></div>
                                        <span>৳ <?php echo $all_user_post_result['car_price']?></span>
                                    </div>
                                </div>
                            <?php } ?>
                    </div>
                    <!-- Recent selling car start -->


                    <!-- Dealer contact start-->
                    <div class="dealer-contact">
                        <div class="contact-details">
                            <div class="item">
                                <div class="icon">
                                    <i class="fa fa-map-marker"></i>
                                </div>
                                <div class="content">
                                    <h5>Address</h5>
                                    <p><?php echo $all_contact_address['address']?></p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="icon">
                                    <i class="fa fa-phone"></i>
                                </div>
                                <div class="content">
                                    <h5>Phone</h5>
                                    <p><span>Mobile:</span> <a href="#"> <?php echo $all_contact_address['mobile']?></a></p>
                                </div>
                            </div>

                            <div class="item">
                                <div class="icon">
                                    <i class="fa fa-envelope-o"></i>
                                </div>
                                <div class="content">
                                    <h5>Email</h5>
                                    <p>
                                        <span>office:</span><a href="mailto:info@themevessel.com"> <?php echo $all_contact_address['email']?></a>
                                    </p>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Dealer contact end-->
                </div>
                <!-- Sidebar end-->
            </div>
        </div>
    </div>
</div>
<!-- Blog body end-->

<!-- Footer begin-->
<?php include'footer.php' ?>