<?php
    require_once ('../class/aboutUs/aboutUs.php');

    /*this code for about us rules in main content*/
    $obj_aboutUs = new AboutUs();
    $rules_result = $obj_aboutUs->all_aboutUs_rules_info();
    $all_result = mysqli_fetch_assoc($rules_result);

    /*this code for choosing us reason in main content*/
    $choose_us_result = $obj_aboutUs->all_choose_us_info();
    $all_choose_us_result = mysqli_fetch_assoc($choose_us_result);

    /*this code for about us Team member in main content*/
    $team_member = $obj_aboutUs->all_team_member_info();

    /*this code for services in main content*/
    $service = $obj_aboutUs->all_service_info();

    /*this code for user post in footer and sidebar*/
    $user_post_result = $obj_aboutUs->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_aboutUs->all_userPost_picture_for_footer();

    /*this code for contact us Address in footer*/
    $contact_address = $obj_aboutUs->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in footer*/
    $social_address = $obj_aboutUs->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);
?>

<!-- Main header begin-->
<?php include'headermain.php';?>

    
    
    <!-- About team meet start-->
    <section class="about-team-meet" style="border: solid;">
        <div class="container">
            <div class="title text-center">Meet The Team Member of Car Bikroy Mela Ltd.</div>
            <div class="row mrg-t-20">
                <?php foreach ($team_member as $all_team_member){?>
                <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12 ">
                    <div class="thumbnail about-box clearfix">
                        <img src="<?php $len=strlen($all_team_member['member_image']); $img=substr($all_team_member['member_image'],18,$len); echo $img;?>" alt="jason.jpg" class="img-responsive">
                        <div class="caption content">
                            <h6><?php echo $all_team_member['member_designation']?></h6>
                            <div class="header b-items-cars-one-info-header  s-lineDownLeft">
                                <h3>
                                    <?php echo $all_team_member['member_name']?>
                                </h3>
                            </div>
                            <p class="text-justify">
                                <?php echo $all_team_member['member_sort_desc']?>
                            </p>
                            <ul class="social-list">
                                <li>
                                    <a href="<?php echo $all_team_member['facebook_link']?>" class="facebook" target="_blank">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo $all_team_member['twitter_link']?>" class="twitter" target="_blank">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo $all_team_member['linkedin_link']?>" class="linkedin" target="_blank">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo $all_team_member['googleplus_link']?>" class="google" target="_blank">
                                        <i class="fa fa-google-plus"></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php } ?>
            </div>
        </div>
    </section>
    <!-- About team meet end-->
</div>
<!-- About body end-->
<!-- Page Section start-->
    <section class="page-section">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <h2 class="title">Why Choose Us</h2>
                    <p class="text-justify"><?php echo $all_choose_us_result['choose_details']?></p>
                    <!-- Icon list -->
                    <ul class="icon-list">
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_one']?>
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_two']?>
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_three']?>
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_four']?>
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_five']?>
                        </li>
                        <li>
                            <i class="fa fa-check"></i>
                            <?php echo $all_choose_us_result['reason_six']?>
                        </li>
                    </ul>
                </div>
                       
                        </div>
                    </div> 
                </div>
            </div>
        </div>
    </section>
    <!-- Page Section end-->

<!-- Serviceslist start-->
<div class="serviceslist text-center">
    <div class="container">
        <div class="title text-center">Our Services</div>
        <div class="row">

            <?php foreach ($service as $all_service){ ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <div class="Services-box">
                        <i class="<?php echo $all_service['service_icon']?>"></i>
                        <h3><?php echo $all_service['service_title']?></h3>
                        <p><?php echo $all_service['service_desc']?></p>
                    </div>
                </div>
            <?php } ?>

        </div>
    </div>
</div>
<!-- Serviceslist end-->

<?php include'footer.php'?>