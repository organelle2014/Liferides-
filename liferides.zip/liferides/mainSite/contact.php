<?php
    require_once ('../class/contactUs/contactUs.php');
    $message = '';

    /*contact us form information insert in database*/
    if(isset($_POST['btn'])){
        $obj_contact_us_form = new ContactUs();
        $message = $obj_contact_us_form->save_contact_us_form_info($_POST);
    }

    /*this code for contact us Address in main content*/
    $obj_contact_us = new ContactUs();
    $contact_address = $obj_contact_us->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in main content*/
    $social_address = $obj_contact_us->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);

    /*this code for user post in footer and sidebar*/
    $user_post_result = $obj_contact_us->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_contact_us->all_userPost_picture_for_footer();

?>


<?php include'headermain.php'?>
<!-- Main header end-->



<!-- Contact us body start-->
<div class="contact-us-body" style="border: solid;">
    <div class="container">
        <div class="row">
            <div class="col-lg-8 col-md-8 col-xs-12">
                <!--Success Message -->
                <h3 class="text-center text-success"><?php echo $message; ?></h3>
                <br>
                <!--end -->
                <h2 class="title">Contact Form</h2>
                <div class="contact-form" style="border: solid; border-radius: 5px; ">
                    <form action="" method="POST" enctype="multipart/form-data">
                        <div class="row">

                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group full-name">
                                    <input type="text" class="input-text" name="full_name" placeholder="Full Name">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group email address">
                                    <input type="text" class="input-text" name="email" placeholder="Email Address">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group Phone Number"> 
                                    <input type="text" class="input-text" name="phone_number" placeholder="Phone Number">
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                <div class="form-group your website">
                                    <input type="text" class="input-text" name="your_website" placeholder="Your Website">
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="form-group message">
                                    <textarea class="input-text" name="message" placeholder="Write message"></textarea>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 mrg-btnn">
                                <input type="submit" name="btn" class=" btn btn-message" value="send message">
                            </div>

                        </div>
                    </form>     
                </div>
            </div>

            <div class="col-lg-4 col-md-4  col-xs-12">
                <!-- contact details start-->
                <div class="contact-details">
                    <div class="item">
                        <div class="icon">
                            <i class="fa fa-map-marker"></i>
                        </div>
                        <div class="content">
                            <h5>Address</h5>
                            <p><?php echo $all_contact_address['address']?></p>
                        </div>
                    </div>

                    <div class="item">
                        <div class="icon">
                            <i class="fa fa-phone"></i>
                        </div>
                        <div class="content">
                            <h5>Phone</h5>
                            <p><span>Mobile:</span> <a href="#"> <?php echo $all_contact_address['mobile']?></a></p>
                        </div>
                    </div>

                    <div class="item">
                        <div class="icon">
                            <i class="fa fa-envelope-o"></i>
                        </div>
                        <div class="content">
                            <h5>Email</h5>
                            <p>
                               <span>office:</span><a href="mailto:info@themevessel.com"> <?php echo $all_contact_address['email']?></a>
                            </p>

                        </div>
                    </div>
                </div>
                <!-- contact details end-->
                
                <!-- share start-->
                <div class="share">
                    <h2>Connect With Us</h2>
                    <ul class="social-list">
                        <li>
                            <a href="<?php echo $all_social_address['facebook']?>" target="_blank" class="facebook">
                                <i class="fa fa-facebook"></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $all_social_address['twitter']?>" target="_blank" class="twitter">
                                <i class="fa fa-twitter"></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $all_social_address['linkedin']?>" target="_blank" class="linkedin">
                                <i class="fa fa-linkedin"></i>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo $all_social_address['googleplus']?>" target="_blank" class="google">
                                <i class="fa fa-google-plus"></i>
                            </a>
                        </li>
                    </ul>
                </div>
                <!-- share end-->
            </div>
        </div>
    </div>
</div>
<!-- Contact us body end-->

<?php include'footer.php'?>