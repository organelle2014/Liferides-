<?php

    /* Client information save in the database*/
    $message = '';
    if(isset($_POST['btn'])){
        require_once('../class/userPost/feedback.php');

        $obj_feedback = new Feedback();
        $message = $obj_feedback->save_cliendFeedback_info($_POST);
    }

    /*this code for user post in footer*/
    require_once ('../class/userPost/userpost.php');
    $obj_userPost = new Userpost();
    $user_post_result = $obj_userPost->all_userPost_info_for_footer();

    /*this code for user post picture in footer*/
    $user_post_picture = $obj_userPost->all_userPost_picture_for_footer();

    /*this code for contact us Address in main content*/
    $contact_address = $obj_userPost->all_contact_address_info();
    $all_contact_address = mysqli_fetch_assoc($contact_address);

    /*this code for contact us Social Address in main content*/
    $social_address = $obj_userPost->all_social_address_info();
    $all_social_address = mysqli_fetch_assoc($social_address);

?>

<?php include'headermain.php'?>
<!-- Main header end-->

<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <!--Success Message -->
            <h3 class="text-center text-success"><?php echo $message; ?></h3>
            <br>
            <!--end -->
            <div class="well" style="margin-top: 20px">
                <h3 class="text-center text-success">Enter Your Valuable Feedback Here</h3><br>

                <form class="form-horizontal" action="" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="client_name" class="col-sm-2 control-label">Client Name</label>
                        <div class="col-sm-8">
                            <input type="text" name="client_name" class="form-control" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="client_type" class="col-sm-2 control-label">Client Type</label>
                        <div class="col-sm-2">
                            <input type="radio" name="client_type" value="Car Buyer"> Car Buyer
                        </div>
                        <div class="col-sm-2">
                            <input type="radio" name="client_type" value="Car Seller"> Car Seller
                        </div>
                        <div class="col-sm-2">
                            <input type="radio" name="client_type" value="Car Dealer"> Car Dealer
                        </div>
                        <div class="col-sm-2">
                            <input type="radio" name="client_type" value="Sell Executive"> Sell Executive
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="feeadback_message" class="col-sm-2 control-label">Feedback Message</label>
                        <div class="col-sm-8">
                            <textarea name="feeadback_message" class="form-control" rows="4" required></textarea>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="client_image" class="col-sm-2 control-label">Client Image</label>
                        <div class="col-sm-8">
                            <input type="file" name="client_image" accept="image/*" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="publication_status" class="col-sm-2 control-label">Publication Status</label>
                        <div class="col-sm-8">
                            <select name="publication_status" class="form-control">
                                <option>---Select Publication Status---</option>
                                <option value="1">Published</option>
                                <option value="0">Unpublished</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="btn" class="col-sm-2 control-label"></label>
                        <div class="col-sm-8">
                            <button type="submit" name="btn" class="btn btn-success btn-block">Send Your Feedback</button>
                        </div>
                    </div>
                </form>
            </div>
            <h1 style="margin-bottom: 200px"></h1>
        </div>
    </div>
</div>

<?php include'footer.php';?>