-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 27, 2019 at 12:14 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_car_bikroy_mela`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aboutus_choose_us`
--

CREATE TABLE `tbl_aboutus_choose_us` (
  `choose_us_id` int(3) NOT NULL,
  `choose_details` text NOT NULL,
  `reason_one` varchar(256) NOT NULL,
  `reason_two` varchar(256) NOT NULL,
  `reason_three` varchar(256) NOT NULL,
  `reason_four` varchar(256) NOT NULL,
  `reason_five` varchar(256) NOT NULL,
  `reason_six` varchar(256) NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aboutus_rules`
--

CREATE TABLE `tbl_aboutus_rules` (
  `rules_id` int(3) NOT NULL,
  `rules_details` text NOT NULL,
  `rules_one` varchar(100) NOT NULL,
  `rules_two` varchar(100) NOT NULL,
  `rules_three` varchar(100) NOT NULL,
  `rules_four` varchar(100) NOT NULL,
  `video` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aboutus_service`
--

CREATE TABLE `tbl_aboutus_service` (
  `service_id` int(3) NOT NULL,
  `service_icon` varchar(100) NOT NULL,
  `service_title` varchar(100) NOT NULL,
  `service_desc` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_aboutus_team`
--

CREATE TABLE `tbl_aboutus_team` (
  `team_member_id` int(3) NOT NULL,
  `member_name` varchar(100) NOT NULL,
  `member_designation` varchar(100) NOT NULL,
  `member_sort_desc` text NOT NULL,
  `facebook_link` varchar(200) NOT NULL,
  `twitter_link` varchar(200) NOT NULL,
  `linkedin_link` varchar(200) NOT NULL,
  `googleplus_link` varchar(200) NOT NULL,
  `member_image` text NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin_login`
--

CREATE TABLE `tbl_admin_login` (
  `admin_id` int(3) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `email_address` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_admin_login`
--

INSERT INTO `tbl_admin_login` (`admin_id`, `admin_name`, `email_address`, `password`) VALUES
(1, 'Admin 1', 'admin@gmail.com', 'e10adc3949ba59abbe56e057f20f883e'),
(2, 'Cell Organelle', 'cellorganelle@gmail.com', 'cell2009');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_blog_post`
--

CREATE TABLE `tbl_blog_post` (
  `blog_post_id` int(3) NOT NULL,
  `post_title` varchar(100) NOT NULL,
  `post_details` text NOT NULL,
  `related_topic` varchar(100) NOT NULL,
  `post_Date` varchar(100) NOT NULL,
  `post_image` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_client_feedback`
--

CREATE TABLE `tbl_client_feedback` (
  `client_feedback_id` int(3) NOT NULL,
  `client_name` varchar(100) NOT NULL,
  `client_type` varchar(100) NOT NULL,
  `feeadback_message` text NOT NULL,
  `client_image` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_us_address`
--

CREATE TABLE `tbl_contact_us_address` (
  `contact_address_id` int(3) NOT NULL,
  `address` text NOT NULL,
  `mobile` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_contact_us_address`
--

INSERT INTO `tbl_contact_us_address` (`contact_address_id`, `address`, `mobile`, `email`) VALUES
(1, 'Opposite Bangertuny Plaza', '+254 716009832', 'liferides@info.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_us_form`
--

CREATE TABLE `tbl_contact_us_form` (
  `contact_form_id` int(3) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_number` varchar(100) NOT NULL,
  `your_website` varchar(100) NOT NULL,
  `message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_contact_us_social_address`
--

CREATE TABLE `tbl_contact_us_social_address` (
  `social_address_id` int(3) NOT NULL,
  `facebook` varchar(100) NOT NULL,
  `twitter` varchar(100) NOT NULL,
  `linkedin` varchar(100) NOT NULL,
  `googleplus` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_post`
--

CREATE TABLE `tbl_user_post` (
  `user_post_id` int(4) NOT NULL,
  `car_name` varchar(100) NOT NULL,
  `car_price` varchar(100) NOT NULL,
  `car_details` text NOT NULL,
  `car_model` varchar(100) NOT NULL,
  `car_registration` varchar(100) NOT NULL,
  `cng_status` varchar(100) NOT NULL,
  `cng_com` varchar(100) NOT NULL,
  `fuel_type` varchar(100) NOT NULL,
  `car_cc` varchar(100) NOT NULL,
  `gear` varchar(100) NOT NULL,
  `all_option` varchar(100) NOT NULL,
  `music` varchar(100) NOT NULL,
  `serial_number` varchar(100) NOT NULL,
  `engine` varchar(100) NOT NULL,
  `mileage` varchar(100) NOT NULL,
  `doors` varchar(100) NOT NULL,
  `condtion` varchar(100) NOT NULL,
  `passenger` varchar(100) NOT NULL,
  `color` varchar(100) NOT NULL,
  `others` varchar(256) NOT NULL,
  `car_image` varchar(100) NOT NULL,
  `publication_status` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user_signup`
--

CREATE TABLE `tbl_user_signup` (
  `user_id` int(3) NOT NULL,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `Confirm` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tbl_user_signup`
--

INSERT INTO `tbl_user_signup` (`user_id`, `first_name`, `last_name`, `email`, `password`, `Confirm`) VALUES
(7, 'cell', 'organelle', 'cellorganelle@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', 'e807f1fcf82d132f9bb018ca6738a19f'),
(8, 'Richard', 'organelle', 'richiejune@yahoo.com', 'e807f1fcf82d132f9bb018ca6738a19f', 'e807f1fcf82d132f9bb018ca6738a19f');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_aboutus_choose_us`
--
ALTER TABLE `tbl_aboutus_choose_us`
  ADD PRIMARY KEY (`choose_us_id`);

--
-- Indexes for table `tbl_aboutus_rules`
--
ALTER TABLE `tbl_aboutus_rules`
  ADD PRIMARY KEY (`rules_id`);

--
-- Indexes for table `tbl_aboutus_service`
--
ALTER TABLE `tbl_aboutus_service`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `tbl_aboutus_team`
--
ALTER TABLE `tbl_aboutus_team`
  ADD PRIMARY KEY (`team_member_id`);

--
-- Indexes for table `tbl_admin_login`
--
ALTER TABLE `tbl_admin_login`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `tbl_blog_post`
--
ALTER TABLE `tbl_blog_post`
  ADD PRIMARY KEY (`blog_post_id`);

--
-- Indexes for table `tbl_client_feedback`
--
ALTER TABLE `tbl_client_feedback`
  ADD PRIMARY KEY (`client_feedback_id`);

--
-- Indexes for table `tbl_contact_us_address`
--
ALTER TABLE `tbl_contact_us_address`
  ADD PRIMARY KEY (`contact_address_id`);

--
-- Indexes for table `tbl_contact_us_form`
--
ALTER TABLE `tbl_contact_us_form`
  ADD PRIMARY KEY (`contact_form_id`);

--
-- Indexes for table `tbl_contact_us_social_address`
--
ALTER TABLE `tbl_contact_us_social_address`
  ADD PRIMARY KEY (`social_address_id`);

--
-- Indexes for table `tbl_user_post`
--
ALTER TABLE `tbl_user_post`
  ADD PRIMARY KEY (`user_post_id`);

--
-- Indexes for table `tbl_user_signup`
--
ALTER TABLE `tbl_user_signup`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_aboutus_choose_us`
--
ALTER TABLE `tbl_aboutus_choose_us`
  MODIFY `choose_us_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_aboutus_rules`
--
ALTER TABLE `tbl_aboutus_rules`
  MODIFY `rules_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_aboutus_service`
--
ALTER TABLE `tbl_aboutus_service`
  MODIFY `service_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `tbl_aboutus_team`
--
ALTER TABLE `tbl_aboutus_team`
  MODIFY `team_member_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_admin_login`
--
ALTER TABLE `tbl_admin_login`
  MODIFY `admin_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_blog_post`
--
ALTER TABLE `tbl_blog_post`
  MODIFY `blog_post_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `tbl_client_feedback`
--
ALTER TABLE `tbl_client_feedback`
  MODIFY `client_feedback_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tbl_contact_us_address`
--
ALTER TABLE `tbl_contact_us_address`
  MODIFY `contact_address_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_contact_us_form`
--
ALTER TABLE `tbl_contact_us_form`
  MODIFY `contact_form_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_contact_us_social_address`
--
ALTER TABLE `tbl_contact_us_social_address`
  MODIFY `social_address_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_user_post`
--
ALTER TABLE `tbl_user_post`
  MODIFY `user_post_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `tbl_user_signup`
--
ALTER TABLE `tbl_user_signup`
  MODIFY `user_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
